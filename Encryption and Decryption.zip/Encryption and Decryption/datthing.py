#this is in no way secure. I'm just fiddlefucking around
from random import * #imports the random library
decrypt = input("What secret message do you need to encrypt?: ")#asks the user for the phrase they want to encrypt
a = []
for x in range (len(decrypt)):
    a.append(randint(0,10))
fileOne = open('key.txt', 'w') #creates the key for decryption
for x in range (len(a)):
    fileOne.write(str(a[x])+ " ") #writes the key to the text file

fileOne.close()
fileTwo = open('encrypted.txt', 'w') #opens the file the encrypted text will be written to
for x in range(len(decrypt)):
    encrypt = ord(decrypt[x]) + a[x] #encrypts the message using a Ceasar Cipher
    fileTwo.write(chr(encrypt)) #writes encrypted character to file
fileTwo.close()


    

    
    
