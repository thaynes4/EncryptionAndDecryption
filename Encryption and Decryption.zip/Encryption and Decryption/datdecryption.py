#decryption program for datthing
fileToRead = input("What's the file we're doing a decrypt? : ")#ask the user for encrypted file
keyToRead = input("And what are we using to do the decrypt? : ")#asks user for the key used in decrypting the file

encryptedFile = open(fileToRead, 'r')#opens encrypted file
flibidyFloppidy = encryptedFile.read()#reads encrypted file
encryptedFile.close()
a = []
with open(keyToRead) as f:
    for line in f:#reads numbers from the key file and adds them to an array
        getOffMyProperty = line.split()
        for x in getOffMyProperty:
            a.append(int(x))     
output = ' '
for x in range(len(flibidyFloppidy)): #uses the array made from the key file to decrypt the line of text from the ecrypted file
    decrypt = ord(flibidyFloppidy[x]) - a[x]
    output += chr(decrypt)

print(output) #prints decrypted message
